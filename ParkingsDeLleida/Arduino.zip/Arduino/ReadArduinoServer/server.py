import requests

from flask import Flask

SERVER_URL = "http://192.168.43.52:8000"
app = Flask(__name__)

def send_to_server(message):
    try:
        response = requests.post(f"{SERVER_URL}/aparcaments/1/update/")
        print(f"Mensaje enviado: {message}")
        print(f"Respuesta: {response.text}")
    except requests.exceptions.RequestException as e:
        print(f"Error: {e}")

@app.route('/beam_unbroken')
def beam_unbroken():
    return "Beam is unbroken", 200

@app.route('/beam_broken')
def beam_broken():
    send_to_server("a")
    return "Beam is broken", 200

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000)