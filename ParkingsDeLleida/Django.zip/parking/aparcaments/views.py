from django.http import JsonResponse
from django.views.generic import TemplateView
from django.shortcuts import get_object_or_404
from django.views import View
from django.utils.decorators import method_decorator
from django.views.decorators.csrf import csrf_exempt
from django.forms.models import model_to_dict
from .models import Aparcament
from django.http import JsonResponse

# Vista para detalles del aparcamiento
@method_decorator(csrf_exempt, name='dispatch')
class AparcamentDetailView(TemplateView):
    template_name = 'aparcament_detail.html'

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['aparcament'] = get_object_or_404(Aparcament, id=kwargs['pk'])
        return context

class AppMovil(View):
    def get(self, request, pk, *args, **kwargs):
        try:
            # Obtén el aparcament por su ID (pk)
            aparcament = Aparcament.objects.get(pk=pk)
            
            # Convierte los atributos del aparcament en un diccionario para el JSON
            data = {
                "id": aparcament.pk,
                "nom": aparcament.nom,
                "places_ocupades": aparcament.places_ocupades,
                "places_totals": aparcament.places_totals,
                "plazas_libres": aparcament.places_totals - aparcament.places_ocupades,
            }
            
            # Devuelve la respuesta en formato JSON
            return JsonResponse(data, status=200)
        
        except Aparcament.DoesNotExist:
            # Manejo de error si no se encuentra el aparcament
            return JsonResponse({"error": "Aparcament not found"}, status=404)

# Vista para manejar POST y DELETE

@method_decorator(csrf_exempt, name='dispatch')
class AparcamentUpdateView(View):
    def post(self, request, pk, *args, **kwargs):
        """
        Maneja la entrada de un coche (POST request).
        """
        aparcament = get_object_or_404(Aparcament, pk=pk)
        if aparcament.places_ocupades < aparcament.places_totals:
            aparcament.places_ocupades += 1
            aparcament.save()
            return JsonResponse({"status": "Car added", "places_ocupades": aparcament.places_ocupades})
        return JsonResponse({"error": "No available spaces"}, status=400)

    def delete(self, request, pk, *args, **kwargs):
        """
        Maneja la salida de un coche (DELETE request).
        """
        aparcament = get_object_or_404(Aparcament, pk=pk)
        if aparcament.places_ocupades > 0:
            aparcament.places_ocupades -= 1
            aparcament.save()
            return JsonResponse({"status": "Car removed", "places_ocupades": aparcament.places_ocupades})
        return JsonResponse({"error": "No cars to remove"}, status=400)
    
# Vista para obtener el estado del aparcamiento
@method_decorator(csrf_exempt, name='dispatch')
class AparcamentStatusView(View):
    def get(self, request, pk, *args, **kwargs):
        aparcament = get_object_or_404(Aparcament, pk=pk)
        return JsonResponse({
            'places_ocupades': aparcament.places_ocupades,
            'places_totals': aparcament.places_totals,
            'plazas_libres': (aparcament.places_totals - aparcament.places_ocupades),
            'nom': aparcament.nom,
        })
