from django.contrib import admin
from .models import Aparcament
# Register your models here.

@admin.register(Aparcament)
class AparcamentAdmin(admin.ModelAdmin):
	pass