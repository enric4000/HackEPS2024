from django.db import models

class Aparcament(models.Model):
    nom = models.CharField(max_length=200)
    places_ocupades = models.IntegerField()
    places_totals = models.IntegerField()

    def __str__(self):
        return self.nom
