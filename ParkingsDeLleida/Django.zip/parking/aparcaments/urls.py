from django.urls import path
from .views import AparcamentDetailView
from .views import AparcamentUpdateView
from .views import AparcamentStatusView
from .views import AppMovil

urlpatterns = [
    path('<int:pk>/', AparcamentDetailView.as_view()),
	path('<int:pk>/status/', AparcamentStatusView.as_view(), name='aparcament-status'),
	path('<int:pk>/update/', AparcamentUpdateView.as_view(), name='aparcament-update'),
	path('API/<int:pk>/', AppMovil.as_view(), name='ApiPalMovil')
]
